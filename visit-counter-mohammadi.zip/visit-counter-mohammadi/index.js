const express = require('express');
const redis = require('redis');

const app = express();
const client = redis.createClient({
  host: 'redis-server',
  port: 6379,
});



var ch_count = 0
var m_count = 0
var t_count=0

client.set('chrome_count', 0);
client.set('mozilla_count', 0);




app.get('/', (req, res) => {
    const app = req.headers['user-agent']     
   
    const appName=app.search('Chrome')
    console.log(appName,app);
    
    if(appName <0){
        client.get('mozilla_count', (err, count) => {
      	const visitsCount = parseInt(count) + 1;
      	m_count = visitsCount
      	t_count=t_count+1
        res.send('Number of visits on chrome: ' + ch_count.toString()
               + '</br> Number of visits on mozilla: ' + m_count.toString()
               +'</br> Number of visits total: ' + t_count.toString());
        client.set('mozilla_count', visitsCount);
    });} 
    else if(appName >=0){
        client.get('chrome_count', (err, count) => {
      	const visitsCount = parseInt(count) + 1;
      	ch_count = visitsCount
      	t_count=t_count+1
        res.send('Number of visits on chrome: ' + ch_count.toString()
               + '</br> Number of visits on mozilla: ' + m_count.toString()
               +'</br> Number of visits total: ' + t_count.toString());
        client.set('chrome_count', visitsCount);
    });}
});

app.get('/app', (req, res) => {
  res.send(req.headers['user-agent']);
});
app.get('/app/clean', (req, res) => {
  const app = req.headers['user-agent']
  res.send(app.search('Chrome'));
});

app.listen(8080, () => {
  console.log('I\'m listening on port 8080');
});

